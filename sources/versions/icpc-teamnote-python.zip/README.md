# ICPC Python Teamnote

압축을 푼 폴더에서 실행합니다. Python 3.10+가 필요합니다.

```powershell
python -m pip install -r requirements-pdf.txt
python -m unittest discover -s tests -v
python scripts/build_teamnote.py
python scripts/verify_pdf.py
```

20쪽. 알고리즘은 python/에 있습니다. 변환 차이는 docs/PORTING.md를 참조하세요.

PDF는 A4 가로 2단, 코드 8.5pt, 최대 25쪽입니다. Windows 맑은 고딕·Consolas를 사용합니다. 다른 환경에서는 TEAMNOTE_FONT와 TEAMNOTE_MONO에 TTF 경로를 지정하세요. PDF의 줄 이어쓰기 표시 | 는 소스 코드가 아닙니다.

원본 49개 항목과 8개 분야를 유지합니다. code/와 docs/upstream/은 원본 출처 및 구조 확인용입니다. 출처: ATTRIBUTION.md 및 docs/UPSTREAM_README.md. 온라인 저지 제출·최대 입력 벤치마크 및 LaTeX 컴파일은 검증하지 않았습니다.

# ICPC Python + C++ Teamnote

압축을 푼 폴더에서 실행합니다. Python 3.10+가 필요합니다.

```powershell
python -m pip install -r requirements-pdf.txt
python -m unittest discover -s tests -v
python scripts/build_mixed.py
python scripts/verify_mixed_pdf.py
python scripts/verify_mixed.py
```

기본판 22쪽. Python 전용 15개, C++ 전용 16개, 양쪽 18개입니다. versions/의 자료 추가판은 8.5pt 23쪽, 9pt 생성기 기준 24쪽입니다. 9pt 추가판은 별도 PDF 검증과 페이지 이미지 렌더링을 수행하지 않았습니다. 9pt 생성은 python scripts/build_mixed.py --supplement --font-size 9 --skip-validation입니다. build_mixed.py와 verify_mixed_pdf.py에 --supplement를 붙여 재생성·검증합니다. 추가 코드와 중복 제거 기록은 supplement/에 있습니다. C++ 검증에는 PATH의 g++가 필요합니다. 사용 조건은 mixed/README.md를 참조하세요.

PDF는 A4 가로 2단, 코드 8.5pt, 최대 25쪽입니다. Windows 맑은 고딕·Consolas를 사용합니다. 다른 환경에서는 TEAMNOTE_FONT와 TEAMNOTE_MONO에 TTF 경로를 지정하세요. PDF의 줄 이어쓰기 표시 | 는 소스 코드가 아닙니다.

원본 49개 항목과 8개 분야를 유지합니다. code/와 docs/upstream/은 원본 출처 및 구조 확인용입니다. 출처: ATTRIBUTION.md 및 docs/UPSTREAM_README.md. 온라인 저지 제출·최대 입력 벤치마크 및 LaTeX 컴파일은 검증하지 않았습니다.
